# app/api/cities.py

import time
import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, delete
from sqlalchemy.exc import IntegrityError

from app.database import get_db
from app.models import City
from app.schemas import (
    CityCreate,
    CityResponse,
    CityCountryCodeResponse,
    CityCountryCodesResponse,
    CityListResponse,
    MetricsResponse,
)
from app.cache import get_cache, CacheManager
from app.kafka_logger import get_kafka_logger, KafkaLogger

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/", response_model=CityResponse, status_code=201)
async def create_city_country_mapping(
    city_data: CityCreate,
    db: AsyncSession = Depends(get_db),
    cache: CacheManager = Depends(get_cache)
):
    """
    Create a new city-country code mapping.
    Now allows multiple country codes for the same city.
    """
    try:
        # Check if this exact combination already exists
        stmt = select(City).where(
            func.lower(City.name) == city_data.name.lower(),
            City.country_code == city_data.country_code
        )
        existing = (await db.execute(stmt)).scalar_one_or_none()
        
        if existing:
            # This exact combination already exists, just return it
            logger.info(f"City-country mapping already exists: {city_data.name} -> {city_data.country_code}")
            return existing
        
        # Create new mapping
        new_city = City(name=city_data.name, country_code=city_data.country_code)
        db.add(new_city)
        await db.commit()
        await db.refresh(new_city)
        
        # Invalidate cache for this city since we added a new country code
        await cache.delete(f"city:{city_data.name.lower()}")
        
        logger.info(f"Created new city-country mapping: {city_data.name} -> {city_data.country_code}")
        return new_city
        
    except IntegrityError as e:
        await db.rollback()
        logger.error(f"Integrity error creating city mapping: {e}")
        raise HTTPException(status_code=400, detail="City-country code mapping already exists")


@router.get("/{city_name}/country-code", response_model=CityCountryCodeResponse)
async def get_city_country_code(
    city_name: str,
    db: AsyncSession = Depends(get_db),
    cache: CacheManager = Depends(get_cache),
    kafka: KafkaLogger = Depends(get_kafka_logger)
):
    """
    Get a country code for a city. If multiple codes exist, returns the first one.
    For all codes, use the /country-codes endpoint.
    """
    start_time = time.time()
    cache_key = f"city:{city_name.lower()}"

    # Try cache first
    cached_value = await cache.get(cache_key)
    if cached_value:
        response_time = time.time() - start_time
        kafka.log_request(city_name, response_time, cache_hit=True, status_code=200)
        return CityCountryCodeResponse(country_code=cached_value)

    # Query database - get the first country code for this city
    stmt = select(City).where(func.lower(City.name) == city_name.lower()).limit(1)
    result = await db.execute(stmt)
    city = result.scalar_one_or_none()

    if not city:
        response_time = time.time() - start_time
        kafka.log_request(city_name, response_time, cache_hit=False, status_code=404)
        raise HTTPException(status_code=404, detail="City not found")

    # Cache the first country code found
    await cache.set(cache_key, city.country_code)
    
    response_time = time.time() - start_time
    kafka.log_request(city_name, response_time, cache_hit=False, status_code=200)
    
    return CityCountryCodeResponse(country_code=city.country_code)


@router.get("/{city_name}/country-codes", response_model=CityCountryCodesResponse)
async def get_city_country_codes(
    city_name: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Get ALL country codes for a city.
    """
    stmt = select(City.country_code).where(func.lower(City.name) == city_name.lower())
    result = await db.execute(stmt)
    country_codes = [row[0] for row in result.fetchall()]
    
    if not country_codes:
        raise HTTPException(status_code=404, detail="City not found")
    
    return CityCountryCodesResponse(
        city_name=city_name,
        country_codes=country_codes,
        total_codes=len(country_codes)
    )


@router.get("/", response_model=CityListResponse)
async def list_cities(
    db: AsyncSession = Depends(get_db),
    page: int = Query(1, ge=1),
    per_page: int = Query(10, ge=1, le=100),
    unique_cities: bool = Query(False, description="If true, returns unique city names only")
):
    """
    List cities. By default shows all city-country mappings.
    Set unique_cities=true to get unique city names only.
    """
    offset = (page - 1) * per_page
    
    if unique_cities:
        # Get unique city names only
        stmt = select(func.distinct(City.name)).offset(offset).limit(per_page)
        result = await db.execute(stmt)
        unique_names = [row[0] for row in result.fetchall()]
        
        # Count total unique cities
        count_stmt = select(func.count(func.distinct(City.name)))
        total = (await db.execute(count_stmt)).scalar_one()
        
        # Create dummy city objects for response
        cities = [
            CityResponse(
                id=0, name=name, country_code="MULTIPLE", 
                created_at=datetime.now(), updated_at=datetime.now()
            ) 
            for name in unique_names
        ]
    else:
        # Get all city-country mappings
        count_stmt = select(func.count()).select_from(City)
        total = (await db.execute(count_stmt)).scalar_one()
        
        stmt = select(City).offset(offset).limit(per_page)
        result = await db.execute(stmt)
        cities = result.scalars().all()
    
    return CityListResponse(
        cities=cities,
        total=total,
        page=page,
        per_page=per_page,
        total_pages=(total + per_page - 1) // per_page
    )


@router.delete("/{city_name}")
async def delete_city_mappings(
    city_name: str,
    db: AsyncSession = Depends(get_db),
    cache: CacheManager = Depends(get_cache),
    country_code: Optional[str] = Query(None, description="Specific country code to delete")
):
    """
    Delete city mappings. If country_code is provided, deletes only that mapping.
    Otherwise, deletes ALL mappings for the city.
    """
    if country_code:
        # Delete specific city-country mapping
        stmt = delete(City).where(
            func.lower(City.name) == city_name.lower(),
            City.country_code == country_code.upper()
        )
    else:
        # Delete all mappings for this city
        stmt = delete(City).where(func.lower(City.name) == city_name.lower())
    
    result = await db.execute(stmt)
    await db.commit()
    
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="City mapping not found")
    
    # Clear cache for this city
    await cache.delete(f"city:{city_name.lower()}")
    
    return {"message": f"Deleted {result.rowcount} mapping(s) for {city_name}"}


@router.get("/metrics", response_model=MetricsResponse)
async def get_metrics(
    cache: CacheManager = Depends(get_cache),
    kafka: KafkaLogger = Depends(get_kafka_logger)
):
    """Get performance metrics for the application."""
    cache_stats = cache.get_stats()
    uptime_seconds = round(time.time() - cache.start_time, 2)
    
    return MetricsResponse(
        cache_metrics=cache_stats,
        performance_metrics={
            "total_requests": kafka.total_requests,
            "cache_hits": kafka.cache_hits,
            "cache_misses": kafka.total_requests - kafka.cache_hits,
            "cache_hit_percentage": (
                kafka.cache_hits / kafka.total_requests * 100
                if kafka.total_requests > 0 else 0
            ),
            "uptime_seconds": uptime_seconds
        }
    )

