# scripts/load_csv_data.py
import asyncio, csv, logging, time
from pathlib import Path
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.future import select
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError

from app.config import settings
from app.models import City

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
log = logging.getLogger(__name__)

CSV_FILE = Path(__file__).parent.parent / "country-code.csv"
BATCH = 500


async def process_single_city(session: AsyncSession, city: str, code: str) -> str:
    stmt = select(City).where(func.lower(City.name) == city.lower())
    existing = (await session.execute(stmt)).scalar_one_or_none()
    if existing:
        if existing.country_code != code:
            existing.country_code = code
            await session.commit()
            return "updated"
        return "skipped"

    try:
        session.add(City(name=city, country_code=code))
        await session.commit()
        return "created"
    except IntegrityError as e:
        await session.rollback()
        log.warning("Integrity error for city '%s': %s", city, e)
        return "error"


async def load():
    if not CSV_FILE.exists():
        log.error("CSV file %s not found", CSV_FILE)
        return

    engine = create_async_engine(settings.database_url, echo=False, pool_pre_ping=True)
    async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    created = updated = skipped = errors = 0
    start = time.time()

    with CSV_FILE.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        rows = [r for r in reader]

    async with async_session() as session:
        for i, row in enumerate(rows, 1):
            city, code = row["City"].strip(), row["Country Code"].strip()
            status = await process_single_city(session, city, code)
            if status == "created":
                created += 1
            elif status == "updated":
                updated += 1
            elif status == "skipped":
                skipped += 1
            else:
                errors += 1

            if i % 1000 == 0:
                log.info("📊 Progress: %s/%s cities processed...", i, len(rows))

    log.info("🎉 CSV data loading completed!")
    log.info("📊 Final Statistics:")
    log.info("   - Total rows in CSV: %s", len(rows))
    log.info("   - Cities created   : %s", created)
    log.info("   - Cities updated   : %s", updated)
    log.info("   - Rows skipped     : %s", skipped)
    log.info("   - Errors           : %s", errors)
    log.info("   - Processing time  : %.2fs", time.time() - start)


if __name__ == "__main__":
    asyncio.run(load())