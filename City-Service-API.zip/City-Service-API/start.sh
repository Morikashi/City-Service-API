#!/bin/bash

# A robust script to start the City Service API and its dependencies.

# --- Colors for better output ---
COLOR_GREEN='\033[0;32m'
COLOR_YELLOW='\033[1;33m'
COLOR_RED='\033[0;31m'
NC='\033[0m' # No Color

# --- Function to print messages ---
info() {
    echo -e "${COLOR_GREEN}[INFO] $1${NC}"
}

error() {
    echo -e "${COLOR_RED}[ERROR] $1${NC}"
}

# --- Step 1: Check for prerequisites and CSV file ---
info "Step 1: Checking for prerequisites..."

if ! command -v docker &> /dev/null; then
    error "Docker could not be found. Please install Docker."
    exit 1
fi
if ! command -v docker-compose &> /dev/null; then
    error "docker-compose could not be found. Please install docker-compose."
    exit 1
fi
if [ ! -f "country-code.csv" ]; then
    error "CSV file 'country-code.csv' not found in project root directory!"
    error "Please place your CSV file (with columns: Country Code, City) in the same directory as this script."
    exit 1
fi
info "Prerequisites are satisfied ✓"

# --- Step 2: Clean up previous runs ---
info "Step 2: Cleaning up previous Docker containers and volumes..."
if [ "$(docker-compose ps -q)" ]; then
    docker-compose down -v --remove-orphans
    info "Previous environment stopped and cleaned."
else
    info "No previous environment found. Skipping cleanup."
fi

# --- Step 3: Start all services using Docker Compose ---
info "Step 3: Starting all services (Postgres, Redis, Kafka, App)..."
docker-compose up --build -d
if [ $? -ne 0 ]; then
    error "docker-compose up command failed. Aborting."
    exit 1
fi
info "All services are starting up..."

# --- Step 4: Wait for services to be healthy ---
info "Step 4: Waiting for all services to become healthy..."

# Wait for PostgreSQL
echo "Waiting for PostgreSQL to be ready (will timeout after 60 seconds)..."
counter=0
while ! docker exec city_service_postgres pg_isready -U postgres -q; do
    if [ $counter -ge 30 ]; then error "PostgreSQL did not become ready in 60 seconds. Aborting." && exit 1; fi
    counter=$((counter+1)); printf "."; sleep 2
done
echo -e "\n${COLOR_GREEN}PostgreSQL is ready. ✓${NC}"

# Wait for Redis
echo "Waiting for Redis to be ready (will timeout after 60 seconds)..."
counter=0
while ! docker exec city_service_redis redis-cli ping | grep -q PONG; do
    if [ $counter -ge 30 ]; then error "Redis did not become ready in 60 seconds. Aborting." && exit 1; fi
    counter=$((counter+1)); printf "."; sleep 2
done
echo -e "\n${COLOR_GREEN}Redis is ready. ✓${NC}"

# Wait for Kafka Broker
echo "Waiting for Kafka to be ready (will timeout after 90 seconds)..."
counter=0
until docker-compose exec -T kafka kafka-topics --bootstrap-server localhost:9092 --list &>/dev/null; do
    if [ $counter -ge 45 ]; then error "Kafka did not become ready in 90 seconds. Aborting." && exit 1; fi
    counter=$((counter+1)); printf "."; sleep 2
done
echo -e "\n${COLOR_GREEN}Kafka is ready. ✓${NC}"

# --- Step 5: Load CSV Data into the Database ---
info "Step 5: Loading data from country-code.csv..."
# --- FIX: Execute the script as a module (-m) so it knows about the 'app' package ---
docker-compose exec -T app python -m scripts.load_csv_data
if [ $? -ne 0 ]; then
    error "Data loading script failed. Please check the output above."
    exit 1
fi
info "Data loaded successfully ✓"

# --- Step 6: Wait for FastAPI application to be ready ---
info "Step 6: Waiting for the City Service API to be healthy..."
counter=0
while ! curl -sf -o /dev/null http://localhost:8000/health; do
    if [ $counter -ge 30 ]; then
        error "The API service did not become healthy in 60 seconds. Aborting."
        error "Tip: Check the application logs with 'docker-compose logs app' for details."
        exit 1
    fi
    counter=$((counter+1)); printf "."; sleep 2
done
echo -e "\n${COLOR_GREEN}City Service API is healthy and running. ✓${NC}"

# --- Step 7: Run Automated API Tests ---
info "Step 7: Running automated API tests inside the container..."
docker-compose exec -T app python -m scripts.test_api
if [ $? -ne 0 ]; then
    error "API tests failed. Please check the output above for errors."
    exit 1
fi
info "All API tests passed successfully! ✓"

# --- Final Step: Display Access Information ---
info "======================================================"
info "            🚀 APPLICATION IS READY! 🚀"
info "======================================================"
info "API Documentation (Swagger): http://localhost:8000/docs"
info "Health Check:                http://localhost:8000/health"
info "Kafka UI:                    http://localhost:8080"
info "To view logs:                docker-compose logs -f"
info "To stop the services:        docker-compose down -v"
info "======================================================"